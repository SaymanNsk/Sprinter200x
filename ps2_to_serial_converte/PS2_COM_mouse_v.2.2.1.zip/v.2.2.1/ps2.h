void ProcessPS2(void);
void InitPS2(void);
void PS2put(unsigned char c);
unsigned char PS2get(void);
unsigned char PS2ready(void);
void WritePS2(unsigned char a);
unsigned char SetupPS2(unsigned char HasWheel);
extern unsigned char ps2state;
